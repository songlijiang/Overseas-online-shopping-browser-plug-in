﻿// ==UserScript==
// @name jimmyjazz Script
// @namespace jimmyjazz
// @include http://www.jimmyjazz.com/*
// @all-frames true
// @require jquery-1.11.3.min.js
// @require config.js
// @require plugin_content.js
// @require jimmyjazz_Xcontent.js
// @require util.js
// ==/UserScript==
$("body").ready(function(){
  startMainWindow("jimmyjazz");
});