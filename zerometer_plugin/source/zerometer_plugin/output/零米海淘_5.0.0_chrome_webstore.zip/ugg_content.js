// ==UserScript==
// @name uggaustralia Script
// @namespace uggaustralia
// @include http://www.uggaustralia.com/
// @require jquery-1.11.3.min.js
// @require config.js
// @require plugin_content.js
// @require ugg_Xcontent.js
// @require util.js
// ==/UserScript==

$("body").ready(function(){
	startMainWindow("ugg");
});